(set-option :timeout 15000)
(set-logic QF_FD)
(assert (and true (not false) true (not false)))
(check-sat)
