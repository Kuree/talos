(set-option :timeout 15000)
(set-logic QF_FD)
(assert (or false (and true false)))
(check-sat)
